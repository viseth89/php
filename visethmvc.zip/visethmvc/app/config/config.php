<?php 
  // DB Params
  // Adjust Accordingly
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', 'Safevase1');
  define('DB_NAME', 'vmvc');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));

  // URL Root
  define('URLROOT', 'http://localhost/php/visethmvc');

  // sITENAME
  define('SITENAME', 'VisethMVC');