<?php
  class Posts {
    public function __construct(){
      echo 'Posts Loaded';
    }
  }